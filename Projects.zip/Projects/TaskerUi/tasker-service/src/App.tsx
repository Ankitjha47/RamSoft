import React, { useEffect, useState } from "react";
import logo from "./logo.svg";
import "./App.css";
import axios from "axios";
import { ThemeProvider } from "@mui/material";
import { theme } from "./components/AppThemeProvider";
import TasksList from "./components/TasksList";

interface TasksDto {
  id: number;
  name: string;
  description: string;
  deadline: string;
  status: string;
}

function App() {
  const [tasks, setTasks] = useState<TasksDto[]>([]);

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    try {
      const response = await axios.get<TasksDto[]>(
        "http://localhost:7298/api/V1/Task/GetAllTasks"
      );
      if (response.status == 200 && response.data != null) {
        setTasks(response.data);
      }
    } catch (error) {
      console.error(error);
    }
  };
  return (
    <ThemeProvider theme={theme}>
      <div className="App">
        <TasksList data={tasks}></TasksList>
      </div>
    </ThemeProvider>
  );
}

export default App;
