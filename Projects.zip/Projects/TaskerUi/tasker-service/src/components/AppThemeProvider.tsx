import { createTheme } from "@mui/material/styles";

const defaultTheme = createTheme();

export const theme = createTheme({});
