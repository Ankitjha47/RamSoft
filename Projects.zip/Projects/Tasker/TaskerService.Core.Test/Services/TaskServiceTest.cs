﻿using AutoFixture;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Moq;
using TaskerService.Core.Interfaces.Repositories;
using TaskerService.Core.Models;
using TaskerService.Core.Services;
using Xunit;

namespace TaskerService.Core.Test.Services
{
    public class TaskServiceTest
    {
        private readonly IFixture _fixture;
        private readonly Mock<ITaskRepository> _taskRepository;
        private readonly TaskService taskService;

        public TaskServiceTest()
        {
            _fixture = new Fixture();
            _taskRepository = new Mock<ITaskRepository>();
            taskService = new TaskService(_taskRepository.Object);
        }

        [Fact]
        private async Task AddTask_ShouldReturData()
        {
            var request = _fixture.Build<TasksRequestDto>().Create();
            var response = _fixture.Build<TasksDto>().Create();

            _taskRepository.Setup(x => x.AddTask(request)).ReturnsAsync(response);

            var result = await taskService.AddTask(request);

            result.Should().NotBeNull();
        }
    }
}
