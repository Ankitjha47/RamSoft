﻿using AutoFixture;
using AutoFixture.AutoMoq;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Net;
using TaskerService.Controllers;
using TaskerService.Core.Interfaces.Services;
using TaskerService.Core.Models;
using Xunit;

namespace TaskerService.Api.Test.Controllers
{
    public class TaskControllerTest
    {

        private readonly IFixture _fixture;
        private readonly Mock<ITaskService> _taskServiceMock;
        private readonly TaskController _sut;
        public TaskControllerTest()
        {
            _fixture = new Fixture();
            _fixture.Customize(new AutoMoqCustomization());
            _taskServiceMock = _fixture.Freeze<Mock<ITaskService>>();
            _sut = new TaskController(_taskServiceMock.Object);
        }

        [Fact]
        public async Task GetAllTasks_ReturnsSuccessStatusCode()
        {
            // Arrange
            List<TasksDto> tasksDto = GetMockTaskData();

            var taskServiceMock = new Mock<ITaskService>();
            _taskServiceMock.Setup(service => service.GetTask()).ReturnsAsync(GetMockTaskData());

            // Act
            var response = await _sut.Get().ConfigureAwait(false);

            // Assert
            Assert.NotNull(response);
            var actualTasks = Assert.IsAssignableFrom<List<TasksDto>>(response.Result.As<OkObjectResult>().Value);
            Assert.Equal(tasksDto.Count, actualTasks.Count);
        }

        [Fact]
        public async Task GetAllTasks_ReturnsInternalServerError()
        {
            // Arrange
            _taskServiceMock.Setup(service => service.GetTask()).ThrowsAsync(new Exception("Internal Server Error"));

            // Act
            var response = await _sut.Get().ConfigureAwait(false);

            // Assert
            Assert.NotNull(response);
            response.Result.As<StatusCodeResult>().StatusCode
                .Should().Equals(500);
        }

        #region Mock return data
        public List<TasksDto> GetMockTaskData()
        {
            List<TasksDto> tasksDtos = new List<TasksDto>();
            TasksDto task1 = new TasksDto
            {
                Id = 1,
                Name = "Add new first Task",
                Description = "This story for add new task in jira",
                Deadline = DateTime.Now.ToString("dd/mm/yyyy"),
                Status = "InProcess",
            };
            TasksDto task2 = new TasksDto
            {
                Id = 2,
                Name = "Add new second Task",
                Description = "This story for add new task in jira",
                Deadline = DateTime.Now.ToString("dd/mm/yyyy"),
                Status = "InProcess",
            };
            TasksDto task3 = new TasksDto
            {
                Id = 3,
                Name = "Add new third Task",
                Description = "This story for add new task in jira",
                Deadline = DateTime.Now.ToString("dd/mm/yyyy"),
                Status = "InProcess",
            };
            TasksDto task4 = new TasksDto
            {
                Id = 4,
                Name = "Add new forth Task",
                Description = "This story for add new task in jira",
                Deadline = DateTime.Now.ToString("dd/mm/yyyy"),
                Status = "InProcess",
            };
            tasksDtos.Add(task1);
            tasksDtos.Add(task2);
            tasksDtos.Add(task3);
            tasksDtos.Add(task4);

            return tasksDtos;
        }

        #endregion
    }
}
