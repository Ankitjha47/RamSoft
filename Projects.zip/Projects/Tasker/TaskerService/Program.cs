using Microsoft.EntityFrameworkCore;
using TaskerService.Core.Interfaces.Repositories;
using TaskerService.Core.Interfaces.Services;
using TaskerService.Core.Services;
using TaskerService.Infrastructure.Data.Contexts;
using TaskerService.Infrastructure.Data.Repositories;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<TaskerDbContext>(db => db.UseSqlServer("Server=localhost;Database=TaskerDB;Trusted_Connection=True;"), ServiceLifetime.Singleton);

builder.Services.AddSingleton<ITaskService, TaskService>();
builder.Services.AddSingleton<ITaskRepository, TaskRepository>();

string[] origins = builder.Configuration.GetValue<string>("Origins").Split(',');

builder.Services.AddCors(options =>
{
    options.AddPolicy(
        "CorsPolicy",
        builder => builder
        .WithOrigins(origins)
        .AllowAnyMethod()
        .AllowAnyHeader()
        .AllowCredentials());
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("CorsPolicy");

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
