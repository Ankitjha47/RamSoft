using Microsoft.AspNetCore.Mvc;
using TaskerService.Core.Interfaces.Services;
using TaskerService.Core.Models;

namespace TaskerService.Controllers
{
    [ApiController]
    [Route("api/V1/[controller]")]
    public class TaskController : ControllerBase
    {
        private readonly ITaskService _taskService;

        public TaskController(ITaskService taskService)
        {
            _taskService = taskService;
        }

        [HttpGet("GetAllTasks")]
        public async Task<ActionResult<List<TasksDto>>> Get()
        {
            try
            {
                var resp = await _taskService.GetTask();

                return resp == null ? NotFound() : Ok(resp);
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPost("AddTask")]
        public async Task<ActionResult<TasksDto>> Add(TasksRequestDto request)
        {
            try
            {
                var resp = await _taskService.AddTask(request);

                return resp == null ? NotFound() : Ok(resp);
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        [HttpPut("UpdateTask")]
        public async Task<ActionResult<TasksDto>> Update(TasksRequestDto request)
        {
            try
            {
                var resp = await _taskService.UpdateTask(request);

                return resp == null ? NotFound() : Ok(resp);
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
    }
}
