﻿using Microsoft.EntityFrameworkCore;
using TaskerService.Infrastructure.Data.Entities;

namespace TaskerService.Infrastructure.Data.Contexts
{
    public class TaskerDbContext : DbContext
    {
        public DbSet<Tasks> Tasks { get; set; }

        public TaskerDbContext(DbContextOptions<TaskerDbContext> options) : base(options)
        {
        }
    }
}
