﻿using Microsoft.EntityFrameworkCore;
using TaskerService.Core.Interfaces.Repositories;
using TaskerService.Core.Models;
using TaskerService.Infrastructure.Data.Contexts;
using TaskerService.Infrastructure.Data.Entities;

namespace TaskerService.Infrastructure.Data.Repositories
{
    public class TaskRepository : ITaskRepository
    {
        private readonly TaskerDbContext _taskerDbContext;
        private readonly bool isMock = true;

        public TaskRepository(TaskerDbContext taskerDbContext)
        {
            _taskerDbContext = taskerDbContext;
        }

        public async Task<TasksDto> AddTask(TasksRequestDto request)
        {
            try
            {
                TasksDto response = null;
                var tasks = new Tasks
                {
                    Name = request.Name,
                    Description = request.Description,
                    Deadline = request.Deadline,
                    Status = request.Status,
                };
                var entity = _taskerDbContext.Tasks.Add(tasks).Entity;

                return Mapper(entity);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public async Task<TasksDto> UpdateTask(TasksRequestDto request)
        {
            try
            {
                TasksDto response = null;
                var query = await _taskerDbContext.Tasks.Where(x => x.Id == request.Id).SingleOrDefaultAsync().ConfigureAwait(false);

                if (query != null)
                {
                    query.Name = request.Name;
                    query.Description = request.Description;
                    query.Deadline = request.Deadline;
                    query.Status = request.Status;

                    _taskerDbContext.Entry(query).State = EntityState.Modified;
                    await _taskerDbContext.SaveChangesAsync().ConfigureAwait(false);
                }

                return Mapper(query);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public async Task<List<TasksDto>> GetTask()
        {
            try
            {
                if (isMock)
                {
                    List<TasksDto> tasksDtos = new List<TasksDto>();
                    TasksDto task1 = new TasksDto
                    {
                        Id = 1,
                        Name = "Add new first Task",
                        Description = "This story for add new task in jira",
                        Deadline = DateTime.Now.ToString("dd/mm/yyyy"),
                        Status = "InProcess",
                    };
                    TasksDto task2 = new TasksDto
                    {
                        Id = 2,
                        Name = "Add new second Task",
                        Description = "This story for add new task in jira",
                        Deadline = DateTime.Now.ToString("dd/mm/yyyy"),
                        Status = "InProcess",
                    };
                    TasksDto task3 = new TasksDto
                    {
                        Id = 3,
                        Name = "Add new third Task",
                        Description = "This story for add new task in jira",
                        Deadline = DateTime.Now.ToString("dd/mm/yyyy"),
                        Status = "InProcess",
                    };
                    TasksDto task4 = new TasksDto
                    {
                        Id = 4,
                        Name = "Add new forth Task",
                        Description = "This story for add new task in jira",
                        Deadline = DateTime.Now.ToString("dd/mm/yyyy"),
                        Status = "InProcess",
                    };
                    tasksDtos.Add(task1);
                    tasksDtos.Add(task2);
                    tasksDtos.Add(task3);
                    tasksDtos.Add(task4);
                    return tasksDtos;
                }
                else
                {
                    var response = await _taskerDbContext.Tasks.ToListAsync();
                    return ListMapper(response);

                }

            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        #region Mapper
        private List<TasksDto> ListMapper(List<Tasks> response)
        {
            if (!response.Any())
            {
                return null;
            }

            return response.Select(x => new TasksDto
            {
                Id = x.Id,
                Name = x.Name,
                Description = x.Description,
                Deadline = x.Deadline.ToString("dd/mm/yyyy"),
                Status = x.Status,
            }).ToList();

        }

        private TasksDto Mapper(Tasks source)
        {
            if (source == null)
                return null;

            return new TasksDto
            {
                Id = source.Id,
                Name = source.Name,
                Description = source.Description,
                Deadline = source.Deadline.ToString("dd/mm/yyyy"),
                Status = source.Status,
            };
        }
        #endregion
    }
}
