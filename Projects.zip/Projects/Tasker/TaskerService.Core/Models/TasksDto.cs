﻿namespace TaskerService.Core.Models
{
    public class TasksDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public String Deadline { get; set; }
        public string Status { get; set; }
    }
}
