﻿using TaskerService.Core.Interfaces.Repositories;
using TaskerService.Core.Interfaces.Services;
using TaskerService.Core.Models;

namespace TaskerService.Core.Services
{
    public class TaskService : ITaskService
    {
        private readonly ITaskRepository _taskRepository;

        public TaskService(ITaskRepository taskRepository)
        {
            _taskRepository = taskRepository;
        }

        public async Task<TasksDto> AddTask(TasksRequestDto request)
        {
            return await _taskRepository.AddTask(request);
        }

        public async Task<TasksDto> UpdateTask(TasksRequestDto request)
        {
            return await _taskRepository.UpdateTask(request);
        }

        public async Task<List<TasksDto>> GetTask()
        {
            return await _taskRepository.GetTask();
        }
    }
}
