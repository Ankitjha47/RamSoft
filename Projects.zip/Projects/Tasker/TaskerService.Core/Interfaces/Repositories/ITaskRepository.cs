﻿using TaskerService.Core.Models;

namespace TaskerService.Core.Interfaces.Repositories
{
    public interface ITaskRepository
    {
        Task<TasksDto> AddTask(TasksRequestDto request);
        Task<TasksDto> UpdateTask(TasksRequestDto request);
        Task<List<TasksDto>> GetTask();
    }
}
