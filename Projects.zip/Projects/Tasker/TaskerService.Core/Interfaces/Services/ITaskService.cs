﻿using TaskerService.Core.Models;

namespace TaskerService.Core.Interfaces.Services
{
    public interface ITaskService
    {
        Task<TasksDto> AddTask(TasksRequestDto request);
        Task<TasksDto> UpdateTask(TasksRequestDto request);
        Task<List<TasksDto>> GetTask();
    }
}
